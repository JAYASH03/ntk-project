# Book_Reader_App

This Project build using CPP language with STL implementation.

PROJECT DESCRIPTION-

Book Reader APP Project-

● Functional Requirements-

=> In this system, there are 2 users who could login/sign up

■ Admin User & Customer User-

=> Admin mainly for now just adds books to system
=> User is reading 1 book at a time, but have history of sessions

■ During a session: s/he views current page of book and can navigate to other books

● Non-Functional Requirements

=> Usability: The system is understandable, usable and compatible with other systems
=> Security, reliability, performance, maintainability & scalability (optional)

● Admin User-

=> Can view his profile, Add books, Logout
=> Optional: Activate new user account, Edit/Delete/Search books, etc

● Customer User-

=> Can view his profile, list current system books, view his current reading sessions

■ Each session for a book, maintains which was last reading page, date of last reading

■ During an opened session: Can Go to next or previous page or stop reading

=> Optional: Search for book, remove a session, jump to page in reading

